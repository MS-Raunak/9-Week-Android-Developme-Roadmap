package com.ms.notesapp_mvvm.ViewModel

import android.app.Application
import androidx.lifecycle.*
import com.ms.notesapp_mvvm.Database.NoteDataBase
import com.ms.notesapp_mvvm.Model.Note
import com.ms.notesapp_mvvm.Repository.NoteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {
    val repository : NoteRepository

    val allNotes : LiveData<List<Note>>

    init {
        val dao = NoteDataBase.getDatabase(application).getNoteDao()
        repository = NoteRepository(dao)
        allNotes = repository.allNotes
    }

    fun deleteNote(note: Note) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteNote(note)
    }
    fun insertNote(note: Note) = viewModelScope.launch(Dispatchers.IO) {
        repository.insertNote(note)
    }

}