package com.ms.notesapp_mvvm.Dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.ms.notesapp_mvvm.Model.Note

@Dao
interface NoteDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(note: Note)

    @Delete
    suspend fun delete(note: Note)

    @Query("SELECT  * FROM note_table ORDER By note ASC")
    fun getAllNotes() : LiveData<List<Note>>
}



// DAO only interact with databse