package com.ms.notesapp_mvvm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ms.notesapp_mvvm.Adapter.INotesAdapter
import com.ms.notesapp_mvvm.Adapter.NoteAdapter
import com.ms.notesapp_mvvm.Model.Note
import com.ms.notesapp_mvvm.ViewModel.NoteViewModel

class MainActivity : AppCompatActivity(), INotesAdapter {
    lateinit var noteViewModel : NoteViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = NoteAdapter(this, this)

        noteViewModel = ViewModelProvider(this,
            ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(NoteViewModel::class.java)

        noteViewModel.allNotes.observe(this, Observer {list->
            list?.let {
                adapter.updateList(it)
            }

        })

    }

    override fun onItemClicked(note: Note) {
        noteViewModel.deleteNote(note)
        Toast.makeText(this, "${note.toString()} Deleted", Toast.LENGTH_LONG).show()
    }

    fun submitData(view: View) {
        val noteText = findViewById<EditText>(R.id.tvInput).text.toString()
        if (noteText.isNotEmpty()){
            noteViewModel.insertNote(Note(noteText))
            Toast.makeText(this, "${noteText} Inserted", Toast.LENGTH_LONG).show()
        }
    }


}