package com.ms.notesapp_mvvm.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView.Adapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.ms.notesapp_mvvm.Model.Note
import com.ms.notesapp_mvvm.R

class NoteAdapter(val context: Context, val listener : INotesAdapter) : Adapter<NoteAdapter.NoteViewHolder>() {
    val allNotes = ArrayList<Note>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val noteViewHolder =
            NoteViewHolder(LayoutInflater.from(context).inflate(R.layout.item_note, parent, false))
        noteViewHolder.deleteBtn.setOnClickListener {
            listener.onItemClicked(allNotes[noteViewHolder.adapterPosition])
        }
        return noteViewHolder
    }

    override fun getItemCount(): Int {
        return allNotes.size
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val currentNotes = allNotes[position]
        holder.textView.text = currentNotes.toString() // cuurntNotes.text
    }

    // nested class
    class NoteViewHolder(itemView: View) : ViewHolder(itemView) {
        val textView = itemView.findViewById<TextView>(R.id.textView)
        val deleteBtn = itemView.findViewById<ImageView>(R.id.deleteBtn)
    }

    fun updateList(newList: List<Note>){
        allNotes.clear()
        allNotes.addAll(newList)
        notifyDataSetChanged()
    }

}

    interface INotesAdapter {
        fun onItemClicked(note: Note)
    }

